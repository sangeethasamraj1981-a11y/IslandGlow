package com.islandglow.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.BatteryManager;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

public class IslandService extends Service {
    private WindowManager wm;
    private View island;
    private TextView status;
    private boolean added = false;
    private final BroadcastReceiver battery = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { updateBattery(i); }
    };

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        Intent stop = new Intent(this, IslandService.class).setAction("STOP");
        PendingIntent pi = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        Notification.Builder nb = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, "islandglow") : new Notification.Builder(this);
        nb.setSmallIcon(android.R.drawable.ic_media_play).setContentTitle("IslandGlow is active")
          .setContentText("Tap Stop to hide the floating Island").setOngoing(true)
          .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", pi);
        startForeground(7, nb.build());
        try {
            registerReceiver(battery, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        } catch (Exception ignored) {}
        showIsland();
    }
    @Override public int onStartCommand(Intent intent, int flags, int id) {
        if (intent != null && "STOP".equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        return START_STICKY;
    }
    private void showIsland() {
        if (!android.provider.Settings.canDrawOverlays(this)) { stopSelf(); return; }
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL); box.setGravity(Gravity.CENTER);
        box.setPadding(dp(18), dp(10), dp(18), dp(10));
        GradientDrawable bg = new GradientDrawable(); bg.setColor(Color.BLACK); bg.setCornerRadius(dp(32)); bg.setStroke(dp(1), 0xFF292D35);
        box.setBackground(bg);
        LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER);
        TextView dot = new TextView(this); dot.setText("●"); dot.setTextColor(0xFFB8FF6A); dot.setTextSize(9);
        TextView music = new TextView(this); music.setText("  ♪  IslandGlow"); music.setTextColor(Color.WHITE); music.setTextSize(12);
        status = new TextView(this); status.setText("  •  Battery"); status.setTextColor(0xFFB8FF6A); status.setTextSize(11);
        row.addView(dot); row.addView(music); row.addView(status); box.addView(row);
        box.setOnClickListener(v -> {
            Intent a = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(a);
        });
        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
          WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL; p.y = dp(18);
        try { wm.addView(box, p); island = box; added = true; }
        catch (Exception e) { stopSelf(); }
    }
    private void updateBattery(Intent i) {
        if (status == null || i == null) return;
        int level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        int pct = (level >= 0 && scale > 0) ? Math.round(level * 100f / scale) : -1;
        int state = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
        boolean charging = state == BatteryManager.BATTERY_STATUS_CHARGING || state == BatteryManager.BATTERY_STATUS_FULL;
        status.setText(charging ? "  ⚡ " + pct + "%" : "  " + pct + "%");
    }
    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel("islandglow", "IslandGlow overlay", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    @Override public void onDestroy() {
        try { unregisterReceiver(battery); } catch (Exception ignored) {}
        if (added && wm != null && island != null) try { wm.removeView(island); } catch (Exception ignored) {}
        stopForeground(true); super.onDestroy();
    }
    @Override public IBinder onBind(Intent i) { return null; }
}
