package com.islandglow.app;

import android.service.notification.NotificationListenerService;

/**
 * Optional notification-access extension point.
 * This starter deliberately does not inspect or forward notification content.
 */
public class IslandNotificationListener extends NotificationListenerService {
}
