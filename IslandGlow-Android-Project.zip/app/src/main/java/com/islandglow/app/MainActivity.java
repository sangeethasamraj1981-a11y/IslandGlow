package com.islandglow.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private int accent = Color.rgb(184, 255, 106);
    private TextView themeLabel;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(8,9,13));
        getWindow().setNavigationBarColor(Color.rgb(8,9,13));
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 41);
        }
        buildUi();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(8,9,13));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(22), dp(22), dp(28));
        scroll.addView(root);

        TextView logo = text("ISLANDGLOW", 13, accent);
        logo.setLetterSpacing(.18f);
        root.addView(logo);
        TextView title = text("Your screen,\\nyour vibe.", 34, Color.WHITE);
        title.setTypeface(null, 1);
        LinearLayout.LayoutParams tp = params(-1, -2); tp.topMargin = dp(14);
        root.addView(title, tp);
        TextView subtitle = text("A free iPhone-inspired island and clock for Android.", 14, 0xFF9EA3B1);
        LinearLayout.LayoutParams sp = params(-1, -2); sp.topMargin = dp(8);
        root.addView(subtitle, sp);

        LinearLayout preview = new LinearLayout(this);
        preview.setOrientation(LinearLayout.VERTICAL);
        preview.setGravity(Gravity.CENTER);
        preview.setBackground(roundBg(0xFF11131A, 28));
        LinearLayout.LayoutParams pp = params(-1, dp(190)); pp.topMargin = dp(24);
        root.addView(preview, pp);
        TextView pill = text("  ●  ♪  IslandGlow     82%  ", 13, Color.WHITE);
        pill.setGravity(Gravity.CENTER);
        pill.setPadding(dp(18), dp(12), dp(18), dp(12));
        pill.setBackground(roundBg(Color.BLACK, 28));
        preview.addView(pill);
        TextView clock = text("09:41", 42, Color.WHITE);
        clock.setTypeface(null, 1);
        LinearLayout.LayoutParams cp = params(-2, -2); cp.topMargin = dp(16);
        preview.addView(clock, cp);
        TextView date = text("THURSDAY  ·  BATTERY READY", 10, 0xFF9EA3B1);
        date.setLetterSpacing(.12f);
        preview.addView(date);

        addSection(root, "QUICK START");
        addButton(root, "Enable floating Island", "Needs “Display over other apps” permission.", v -> enableIsland());
        addButton(root, "Always-on style clock", "Opens a dim, black clock screen. Not a system-level AOD.", v -> startActivity(new Intent(this, AodActivity.class)));
        addButton(root, "Notification access settings", "Optional. Android asks you to grant this manually.", v -> {
            try { startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)); }
            catch (Exception e) { toast("Open Settings and search for Notification access."); }
        });
        addButton(root, "Charging and music demo", "Shows the Island overlay with live charging status.", v -> enableIsland());

        addSection(root, "PERSONALISE");
        themeLabel = text("Accent: Lime", 14, Color.WHITE);
        LinearLayout.LayoutParams lp = params(-1, -2); lp.topMargin = dp(4);
        root.addView(themeLabel, lp);
        addButton(root, "Change accent colour", "Cycle through free built-in themes.", v -> {
            if (accent == Color.rgb(184,255,106)) { accent = Color.rgb(118,208,255); themeLabel.setText("Accent: Sky"); }
            else if (accent == Color.rgb(118,208,255)) { accent = Color.rgb(255,126,190); themeLabel.setText("Accent: Pink"); }
            else { accent = Color.rgb(184,255,106); themeLabel.setText("Accent: Lime"); }
            themeLabel.setTextColor(accent);
            toast("Theme preview updated.");
        });

        TextView note = text("Battery note: leaving a bright clock on for long periods can use extra power. Android or XOS may stop overlays to save battery.", 12, 0xFF858B99);
        LinearLayout.LayoutParams np = params(-1, -2); np.topMargin = dp(22);
        root.addView(note, np);
        setContentView(scroll);
    }

    private void enableIsland() {
        if (!Settings.canDrawOverlays(this)) {
            new AlertDialog.Builder(this)
                .setTitle("Allow Island overlay?")
                .setMessage("Android needs permission to show the floating Island over other apps. You can revoke this anytime in Settings.")
                .setNegativeButton("Not now", (d,w) -> {})
                .setPositiveButton("Open settings", (d,w) -> {
                    Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                    startActivity(i);
                }).show();
            return;
        }
        Intent service = new Intent(this, IslandService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
        toast("Island enabled. Pull down notifications to stop it.");
    }

    private void addSection(LinearLayout root, String name) {
        TextView t = text(name, 11, accent);
        t.setLetterSpacing(.15f);
        LinearLayout.LayoutParams p = params(-1, -2); p.topMargin = dp(26); p.bottomMargin = dp(10);
        root.addView(t, p);
    }
    private void addButton(LinearLayout root, String title, String desc, View.OnClickListener click) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(15), dp(16), dp(15));
        card.setBackground(roundBg(0xFF151821, 18));
        card.setClickable(true); card.setFocusable(true); card.setOnClickListener(click);
        TextView t = text(title, 16, Color.WHITE); t.setTypeface(null, 1); card.addView(t);
        TextView d = text(desc, 12, 0xFF9EA3B1);
        LinearLayout.LayoutParams dp = params(-1, -2); dp.topMargin = dp(5);
        card.addView(d, dp);
        LinearLayout.LayoutParams p = params(-1, -2); p.bottomMargin = dp(9);
        root.addView(card, p);
    }
    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s.replace("\\n", "\n")); t.setTextSize(size); t.setTextColor(color);
        return t;
    }
    private android.graphics.drawable.GradientDrawable roundBg(int color, int radius) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private LinearLayout.LayoutParams params(int w, int h) { return new LinearLayout.LayoutParams(w, h); }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
}
