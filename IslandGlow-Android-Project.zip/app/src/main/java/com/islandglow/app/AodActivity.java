package com.islandglow.app;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AodActivity extends Activity {
    private final Handler handler = new Handler();
    private TextView clock, date;
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (clock != null) clock.setText(new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date()));
            if (date != null) date.setText(new SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(new Date()).toUpperCase(Locale.getDefault()));
            handler.postDelayed(this, 15000);
        }
    };
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        getWindow().setStatusBarColor(Color.BLACK); getWindow().setNavigationBarColor(Color.BLACK);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.BLACK); root.setPadding(20,20,20,20);
        TextView brand = new TextView(this); brand.setText("ISLANDGLOW"); brand.setTextColor(0xFFB8FF6A); brand.setTextSize(12); brand.setLetterSpacing(.18f);
        root.addView(brand);
        clock = new TextView(this); clock.setTextColor(0xFFE8EAF0); clock.setTextSize(68); clock.setTypeface(null, 1); clock.setGravity(Gravity.CENTER);
        root.addView(clock);
        date = new TextView(this); date.setTextColor(0xFF777D8A); date.setTextSize(12); date.setLetterSpacing(.08f);
        root.addView(date);
        TextView hint = new TextView(this); hint.setText("\\nTap anywhere to close"); hint.setTextColor(0xFF555B66); hint.setTextSize(12);
        root.addView(hint);
        root.setOnClickListener(v -> finish());
        setContentView(root); tick.run();
    }
    @Override protected void onDestroy() { handler.removeCallbacks(tick); super.onDestroy(); }
}
