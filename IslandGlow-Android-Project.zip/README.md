# IslandGlow (Android)

A free, iPhone-inspired Dynamic Island and always-on-style clock concept for Android, initially configured for Infinix X6815C / Android 13.

## Included
- Dark, minimal clock dashboard and AOD-style clock screen
- Optional floating Island overlay (requires Android “Display over other apps” permission)
- Charging status indicator in the Island
- Music status placeholder/extension point
- Notification access setup shortcut (optional; Android requires the user to enable it manually)
- Accent/theme selector
- GitHub Actions workflow to build a debug APK

## Important Android limits
- This is an original iPhone-inspired design, not Apple software.
- Android apps cannot guarantee a true system-level AOD. The AOD-style screen is an app screen and may turn off or be blocked by the device's power management.
- The floating Island requires overlay permission. Android/OEM policies can hide overlays on the lock screen or restrict background execution.
- Notification access is optional and powerful. Only enable it if you understand that this grants the app access to notification content.
- Music controls and notification mirroring are starter features; the initial version shows a media/charging status pill but does not read private notification contents.
- Always-on pixels use extra battery. Prefer short timeout and low brightness.
- No root, paid service, or cable is required.

## Build a debug APK
### With Android Studio
1. Open this folder in Android Studio.
2. Let Gradle sync finish (Android Studio may download Gradle and Android SDK components).
3. Select **Build -> Build Bundle(s) / APK(s) -> Build APK(s)**.
4. The debug APK will be under `app/build/outputs/apk/debug/app-debug.apk`.

### With GitHub
1. Create a GitHub repository named `IslandGlow`.
2. Upload/push the contents of this folder to the repository's default branch.
3. Open **Actions** and run the **Build IslandGlow APK** workflow (or push a commit).
4. Download the `IslandGlow-debug-apk` artifact from the successful workflow run.

## Permissions
- `SYSTEM_ALERT_WINDOW`: requested through Android Settings when you enable the floating Island.
- `POST_NOTIFICATIONS`: runtime permission on Android 13+ for the foreground service notification.
- `FOREGROUND_SERVICE`: keeps the Island service visible while enabled.
- `BIND_NOTIFICATION_LISTENER_SERVICE` is declared only for an optional notification listener service; the user must enable access in Settings. The starter does not read notification content.

## Target
- minSdk 26 (Android 8.0)
- compileSdk / targetSdk 35
- Java 17
